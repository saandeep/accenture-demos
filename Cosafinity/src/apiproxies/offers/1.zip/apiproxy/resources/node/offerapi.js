var express = require('express');
var usergrid = require('usergrid');
var url = require('url');

var app = new express();
var client = new usergrid.client({
    orgName:'cosafinity',
    appName:'sandbox',
    URI:'https://api.usergrid.com',
    logging: true, //optional - turn on logging, off by default
    buildCurl: true //optional - turn on curl commands, off by default
});

//Create Offer
app.post('/',function(req,res){
  //Get Stores from usergrid
  var dataChunk;
	req.on('data', function(chunk) {
	      dataChunk+= (chunk.toString());
	  	
	    });
	req.on('end',function(){
		var options = {'method':'POST','endpoint':'offers','body':dataChunk};
		client.request(options,function(error,response){
			if(!error){
				res.writeHead(200, {'Content-Type':'application/json'}) ;
				res.end(JSON.stringify(response));
			}else{
				res.writeHead(500,{'Content-Type':'application/json'});
				res.end(JSON.stringify(options));
			}
  		});
	});
});

app.get('/:offerid',function(req,res){
	var options = {method:'GET','endpoint':'offers/' + req.params.offerid};
	client.request(options,function(error,response){
		if(!error){
			res.writeHead(200, {'Content-Type':'application/json'}) ;
			res.end(JSON.stringify(response));

		}else{
			res.writeHead(500,{'Content-Type':'application/json'});
			res.end(JSON.stringify(options));
		}
  });
});

app.get('/:offerid/products',function(req,res){
	var options = {method:'GET','endpoint':'offers/' + req.params.offerid + '/contains_product/products'};
	client.request(options,function(error,response){
		if(!error){
			res.writeHead(200, {'Content-Type':'application/json'}) ;
			res.end(JSON.stringify(response));

		}else{
			res.writeHead(500,{'Content-Type':'application/json'});
			res.end(JSON.stringify(options));
		}
  });
});

app.post('/:offerid/products/:productid',function(req,res){
  var options = {'method':'POST', 'endpoint':'offers/' + req.params.offerid  + '/contains_product/products/' +req.params.productid};
  client.request(options,function(error,response){
		if(!error){
			var ops = {method:"GET",endpoint:'products/'+req.params.productid+'/connecting/lists_default'};
			client.request(ops,function(error1,response1){
				var j ;
				for(j=0;j<response1.entities.length;j++){
					var notify = {method:"POST",endpoint:'users/' + response1.entities[j].uuid + '/notifications',
                                  body:{"payloads":{"google":"New offer for you"}}};

					client.request(notify,function(e,re){console.log('notification done')});				
					var applenotify = {method:"POST",endpoint:'users/' + response1.entities[j].uuid + '/notifications',
                                  body:{"payloads":{"apple":"New offer for you"}}};

					client.request(applenotify,function(e,re){console.log('notification done')});				

        		}
			});
			res.writeHead(200, {'Content-Type':'application/json'}) ;
			res.end(JSON.stringify(response));

		}else{
			res.writeHead(500,{'Content-Type':'application/json'});
			res.end(JSON.stringify(options));
		}
  });
});


app.listen(3000);
